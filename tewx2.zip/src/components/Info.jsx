import React from "react";

function Info() {
  return (
    <div class="note">
      <h1>BOOTCAMPS</h1>
      <h1>Javascript and Frontend with ReactJS </h1>
      <p>A basic Web dev ReactJS Bootcamp</p>
    </div>
  );
}
export default Info;
